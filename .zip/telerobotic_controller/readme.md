This is the telerobotic_controller plugin for OpenROV Cockpit.

Remote control of OpenROV over the Internet

Report issues in the primary liveview repository: https://github.com/OpenROV/liveview/issues
